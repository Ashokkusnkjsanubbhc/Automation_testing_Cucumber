package i_o_file;


	import java.io.FileWriter;
	import java.io.IOException;
	public class io1 {
	    public static void main(String[] args) {
	        try {
	            FileWriter reader = new FileWriter("C:\\Users\\LabsKraft\\Downloads\\test1228.txt");
	            reader.write("Hello, world!\n");
	            reader.write("This is a second line.");
	            reader.close(); // Always close the writer
	            System.out.println("Successfully written to the file.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
