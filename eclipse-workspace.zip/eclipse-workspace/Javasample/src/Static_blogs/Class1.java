package Static_blogs;

public class Class1 {
	{
		System.out.println("Instance block-1");
	}
	{
		System.out.println("Instance block-2");
	}
	static {
		System.out.println("static block-1");

	}
	static {
		System.out.println("static block-2");

	}
	Class1(){
		System.out.println(" aaa"); // tonexecute the businees logic 

	}
	Class1(int a){
		System.out.println("A :"+a);

	}
	public static void main(String[] args) {
   new Class1();
   new Class1(1898797);
	}

}
