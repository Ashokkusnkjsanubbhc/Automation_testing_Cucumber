package Collection;
import java.util.*;
public class Linkedlist {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		LinkedList<String> al=new LinkedList<String>();
		  al.add("Samsung");
		  al.add("LG");
		  al.add("Samsung");
		  al.add("Siemens");
		 
		
		  Iterator<String> itr=al.iterator();
		  while(itr.hasNext()){
		   System.out.println(itr.next());
	}
}}

