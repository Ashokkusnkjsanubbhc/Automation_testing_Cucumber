package Collection;


	import java.util.HashSet;
	public class hashset1 {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			HashSet<String> cars = new HashSet<String>();
		    cars.add("Volvo");
		    cars.add("BMW");
		    cars.add("Ford");
		    cars.add("BMW");
		    cars.add("NULL");
		    cars.add("Mazda");
		    cars.remove("Volvo");
		    for (String i : cars) {
		      System.out.println(i);
		    }
		}
}
