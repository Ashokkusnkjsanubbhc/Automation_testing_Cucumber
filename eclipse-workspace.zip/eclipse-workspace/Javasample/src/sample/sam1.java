package sample;
import java.util.Scanner;
public class sam1 {
    public static double age() {
    	Scanner in=new Scanner (System.in);
    	boolean valid =false;
    	double input =0;
    	while(!valid) {
    		System.out.println("enter your age <100");
    		input=in.nextDouble();
    		if(input>0&&input<100) {
    			valid =true;
    			System.out.println("this is coreect age");
    		}
    		else {
    			System.out.println("sorry invalid age");
    		}
  }
    	return input;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a=age();
		System.out.println(a);

	}

}
