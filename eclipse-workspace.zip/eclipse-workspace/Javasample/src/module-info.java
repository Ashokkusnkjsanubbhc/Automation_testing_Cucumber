/**
 * 
 */
/**
 * 
 */
module Javasample {
	requires java.desktop;
}