package Encapsultion;

public class class2 {

	public static void main(String[] args) {
    encap person =new encap();
    person.setName("Ashok");
    person.setAge(123);
    System.out.println("Name"+person.getName());
    System.out.println("age"+person.getAge());
	}

}
