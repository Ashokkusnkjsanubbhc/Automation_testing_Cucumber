package Encapsultion;

public class encap2class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap2 car=new encap2("Toyata",2025);
		System.out.println("Model"+car.getModel());
		System.out.println("Model"+car.getYear());


	}

}
