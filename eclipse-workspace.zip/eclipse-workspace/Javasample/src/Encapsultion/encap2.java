package Encapsultion;

public class encap2 {
	private String model;
	private int year;
	

	public String getModel() {
		return model;
	}


	public int getYear() {
		return year;
	}



	public encap2(String model, int year) {
		super();
		this.model = model;
		this.year = year;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
