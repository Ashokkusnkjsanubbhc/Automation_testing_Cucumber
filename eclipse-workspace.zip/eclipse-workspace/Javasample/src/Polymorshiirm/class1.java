package Polymorshiirm;

public class class1 {
	void m1(int a) {
		System.out.println("1 arguments");
	}
	void m1(int a,int b) {
		System.out.println("2 arguments");
	}
	void m1(char a) {
		System.out.println("3 arguments");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         class1 t= new class1();
         t.m1(10);
         t.m1(10,20);
         t.m1('r');
	}

}
