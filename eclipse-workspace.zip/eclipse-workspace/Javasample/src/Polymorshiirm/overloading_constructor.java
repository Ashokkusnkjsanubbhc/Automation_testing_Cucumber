package Polymorshiirm;

public class overloading_constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
