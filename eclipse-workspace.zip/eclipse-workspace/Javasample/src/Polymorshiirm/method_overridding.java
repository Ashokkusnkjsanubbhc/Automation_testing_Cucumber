package Polymorshiirm;

public class method_overridding {

	public static void main(String[] args) {
        
	}

}
