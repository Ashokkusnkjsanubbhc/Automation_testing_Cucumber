package Polymorshiirm;

public class Operator_overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10+23);
		System.out.println("ashok"+"kumar");
		System.out.println(10+"kumar");
		System.out.println(10+'a'+"Ashok"+5387);

	

	}

}
