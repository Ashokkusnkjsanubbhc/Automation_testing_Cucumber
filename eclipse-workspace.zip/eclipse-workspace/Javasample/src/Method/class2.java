package Method;

public class class2 {

		void m1(int a,String ch) {
			System.out.println(a+" "+ch);
		}
		static void m2(String a,double b) {
			System.out.println(a+" "+b);
		}

	
public static void main(String[] args) {

	class2 t=new class2();
	t.m1(10,"ashokkumar");
	m2("aaaa",2.0);
	

}
}
