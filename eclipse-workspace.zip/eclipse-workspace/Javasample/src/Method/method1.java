package Method;

public class method1 {
	void m1() {
		System.out.println("hello");
	}
	static void m2() {
		System.out .println("Ashok kUmar");
	}

	public static void main(String[] args) {
		method1 t=new method1();
		t.m1();
	 method1.m2();
		
        
	}

}
