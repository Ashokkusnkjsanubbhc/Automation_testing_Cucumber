package Inheritance;

 class class2 {
	int a=10;
	int b=20;
	}
public class Class1 extends class2{
int a=100;
int b=200;
void add(int a,int b) {
	System.out.println(a+b);//local varible
	System.out.println(this.a+this.b);//instance class
	System.out.println(super.a+super.b);//superclass

}



	public static void main(String[] args) {
		//Class1 t=new Class1();
		new Class1().add(23,425);

	}

}
