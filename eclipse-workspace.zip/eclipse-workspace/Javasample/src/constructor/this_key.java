package constructor;

public class this_key {
	char a;
	this_key(){
		this.a=a;
		
	}
	void func() {
		System.out.println('A'+"   "+a);
	}

	public static void main(String[] args) {
       this_key t=new this_key();
       t.func();
	}

}
