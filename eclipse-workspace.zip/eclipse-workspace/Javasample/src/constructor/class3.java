package constructor;

public class class3 {
	void m1() {
		System.out.println("M1 method");
	}
	class3(){
		System.out.println("Cons with o argumnets");
	}
	class3(int a){
		System.out.println("Cons with 1 argumnets");

	}
	public static void main(String args[]) {
		class3 t= new class3();
		t.m1();
		class3 t1=new class3(10);
		t1.m1();
		
		
}

}
