package constructor;

public class para_constructor {
	int id;
	String name;
	float sal;
	
	para_constructor(){
		id=122;
		name="ashok kumar d";
		sal=3987;
		
	}
	void disp() {
	System.out.println("id"+id);
	System.out.println("name"+name);	
     System.out.println("sal"+sal);	

	}
	public static void main(String[] args) {
		para_constructor t=new para_constructor();
		t.disp();
	}

}
