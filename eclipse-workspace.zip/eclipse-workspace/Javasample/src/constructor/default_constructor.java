package constructor;

public class default_constructor {
	int id;
	String name;
	float sal;
	void disp() {
	System.out.println("id"+id);
	System.out.println("name"+name);	
     System.out.println("sal"+sal);	

	}
	public static void main(String[] args) {
		default_constructor t=new default_constructor();
		t.disp();
	}

}
