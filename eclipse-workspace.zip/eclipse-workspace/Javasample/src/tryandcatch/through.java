package tryandcatch;

public class through {
	static void checkage(int age) {
		if(age < 18) {
			throw new ArithmeticException("Access denied -you must be at least 18 year oold");
		}
		else {
			System.out.println("Access granted you are old enough");
		}
	}
	public static void main(String[] args) {
		checkage(15);
	}

}
