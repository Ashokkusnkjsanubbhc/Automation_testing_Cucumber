package tryandcatch;

public class class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int res=10/0;
		}
		catch(ArithmeticException e) {
			System.out.println("Exception error"+e);
		}
		System.out.println("I willl always execute whenever error occurs");

	}
}
