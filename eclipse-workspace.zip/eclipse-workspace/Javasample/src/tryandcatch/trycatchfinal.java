package tryandcatch;

public class trycatchfinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] mynumbers= {1,2,3};
			System.out.println(mynumbers[10]);
		}
		catch(Exception e){
			System.out.println("something went worng");

		}
		finally{
			System.out.println("The 'try catch' is finished");

		}

	}

}
