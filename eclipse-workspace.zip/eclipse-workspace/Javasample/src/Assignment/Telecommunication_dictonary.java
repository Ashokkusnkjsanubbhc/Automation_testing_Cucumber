package Assignment;

	import java.util.ArrayList;
	import java.util.Scanner;

	class Person {
	    String name;
	    String surname;
	    String phoneNumber;
	    String email;
	    String place;

	    public Person(String name, String surname, String phoneNumber, String email, String place) {
	        this.name = name;
	        this.surname = surname;
	        this.phoneNumber = phoneNumber;
	        this.email = email;
	        this.place = place;
	    }

	   
	}

	// Main class
	public class Telecommunication_dictonary {
	    public static void main(String[] args) {
	        ArrayList<Person> directory = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);
	        int choice;

	        do {
	            System.out.println("----- Telephone Dictionary Menu -----");
	            System.out.println("1. Add New Entry");
	            System.out.println("2. Display All Entries");
	            System.out.println("3. Exit");
	            System.out.print("Enter your choice: ");
	            choice = Integer.parseInt(scanner.nextLine());

	            switch (choice) {
	                case 1:
	                    // Input new person data
	                    System.out.print("Enter First Name: ");
	                    String name = scanner.nextLine();
	                    System.out.print("Enter Surname: ");
	                    String surname = scanner.nextLine();
	                    System.out.print("Enter Phone Number: ");
	                    String phone = scanner.nextLine();
	                    System.out.print("Enter Email ID: ");
	                    String email = scanner.nextLine();
	                    System.out.print("Enter Place: ");
	                    String place = scanner.nextLine();

	                    // Add to directory
	                    directory.add(new Person(name, surname, phone, email, place));
	                    System.out.println("Entry added successfully!\n");
	                    break;

	                case 2:
	                    System.out.println("\n----- Telephone Directory -----");
	                    if (directory.isEmpty()) {
	                        System.out.println("No entries found.");
	                    } else {
	                        for (Person p : directory) {
	                            System.out.println(p);
	                        }
	                    }
	                    break;

	                case 3:
	                    System.out.println("Exiting program. Goodbye!");
	                    break;

	                default:
	                    System.out.println("Invalid choice. Please select again.");
	            }

	        } while (choice != 3);

	        scanner.close();
	    }
	}

