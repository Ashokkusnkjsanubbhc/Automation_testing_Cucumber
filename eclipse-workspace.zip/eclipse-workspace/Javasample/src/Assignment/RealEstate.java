package Assignment;


	import java.util.Scanner;

	class RealEstate {
	    int sqft;
	    int pricePerSqFt = 500;

	    RealEstate(int sqft) {
	        this.sqft = sqft;
	    }

	    void calculateTotalPrice() {
	        double basePrice = sqft * pricePerSqFt;
	        double registrationTax = basePrice * 0.08;  // 8%
	        double gst = basePrice * 0.03;              // 3%
	        double totalPrice = basePrice + registrationTax + gst;

	        System.out.println("Base Price: ₹" + basePrice);
	        System.out.println("Registration Tax (8%): ₹" + registrationTax);
	        System.out.println("GST (3%): ₹" + gst);
	        System.out.println("Total Price to be Paid: ₹" + totalPrice);
	    }

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter total area in square feet: ");
	        int area = sc.nextInt();

	        RealEstate flat = new RealEstate(area);
	        flat.calculateTotalPrice();
	    }
	}

