package looping;
import java.util.Scanner;
public class ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		int a=sc.nextInt();
		if (a==10){
			System.out.println("hiii");
		}
		else if(a<23) {			System.out.println("hiii");

 
	}

	}}
