package Instance_blogs;

public class class1 {
	class1(){
		System.out.println("0 arg constructor");
	}
	{
		System.out.println("instance blocks");
	}
	{
		System.out.println("instance blocks1");
	}
   public static void main(String[] args) {
	   new class1();
   }
}
