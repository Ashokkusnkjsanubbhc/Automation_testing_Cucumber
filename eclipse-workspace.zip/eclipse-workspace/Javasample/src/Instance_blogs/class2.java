package Instance_blogs;

public class class2 {
	class2(){
		System.out.println("0 arg constructor");
	}
	class2(int a){
		System.out.println("A"+a);

	}
	public static void main(String args[]) {
		//class2 t=new class2();t.
		new class2(78);
	}

}
