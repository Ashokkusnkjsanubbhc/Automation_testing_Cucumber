
	package utility;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import io.github.bonigarcia.wdm.WebDriverManager;

	public class BrowserFactory {
	    public static WebDriver startApplication() {
	        WebDriverManager.chromedriver().setup();
	        return new ChromeDriver();
	    }

	    public static void quitBrowser(WebDriver driver) {
	        driver.quit();
	    }
	}

