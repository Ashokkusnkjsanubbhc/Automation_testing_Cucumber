package steps;


import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
public class RegistrationSteps {
    WebDriver driver;
    @Given("the user is on the registration page")
    public void the_user_is_on_the_registration_page() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://demoqa.com/automation-practice-form");
    }
    @When("the user enters first name {string}")
    public void the_user_enters_first_name(String fname) {
        driver.findElement(By.id("firstName")).sendKeys(fname);
    }
}