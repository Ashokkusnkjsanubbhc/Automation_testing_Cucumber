package tests;
import base.BaseClass;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebElement;

import pages.*;
public class SauceDemoTest {
    @Test
    public void testEndToEndCheckoutFlow() throws InterruptedException {
        BaseClass.initBrowser();
        LoginPage login = new LoginPage(BaseClass.driver);
        login.login("standard_user", "secret_sauce");
        Assert.assertTrue("Login failed", login.isLoggedIn());
        ProductsPage products = new ProductsPage(BaseClass.driver);
        products.addProducts();
        Assert.assertEquals("Cart count mismatch", 2, products.getCartCount());
        CartPage cart = new CartPage(BaseClass.driver);
        cart.goToCheckout();
        Checkout checkout = new Checkout(BaseClass.driver);
        checkout.enterDetails("Deepan", "MS", "600001");
        checkout.finishOrder();
        HomePage home = new HomePage(BaseClass.driver);
        Assert.assertTrue("Order not confirmed", home.isConfirmed());
        home.goHomeAndLogout();
        public void testTextBoxInputtrue() {
            // Locate the text box by ID
            WebElement textBox = driver.findElement(By.name("my-text"));
            // Enter text
            String input = "TestNG Example";
            textBox.clear();
            textBox.sendKeys(input);
            // Get value and assert it
            String actualValue = textBox.getAttribute("value");
            Assert.assertEquals(actualValue, input, "Text box value doesn't match");
        }
        
        public void testTextBoxInputfalse() {
            // Locate the text box by ID
            WebElement textBox = driver.findElement(By.name("my-text"));
            // Enter text
            String input = "TestNG Example";
            textBox.clear();
            textBox.sendKeys("1234567");
            // Get value and assert it
            String actualValue = textBox.getAttribute("value");
            Assert.assertEquals(actualValue, input, "Text box value doesn't match");
        BaseClass.quitBrowser();
        
    }
}
}
