package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CartPage {
    WebDriver driver;
    By cartIcon = By.className("shopping_cart_link");
    By checkoutBtn = By.id("checkout");
    public CartPage(WebDriver driver) {
        this.driver = driver;
    }
    public void goToCheckout() throws InterruptedException {
        driver.findElement(cartIcon).click();
        Thread.sleep(1000);
        driver.findElement(checkoutBtn).click();
    }
}