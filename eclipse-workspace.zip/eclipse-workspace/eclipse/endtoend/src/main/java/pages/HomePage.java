package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class HomePage {
    WebDriver driver;
    By backHomeBtn = By.id("back-to-products");
    By menuBtn = By.id("react-burger-menu-btn");
    By logoutBtn = By.id("logout_sidebar_link");
    By confirmation = By.className("complete-header");
    public HomePage(WebDriver driver) {
        this.driver = driver;
    }
    public boolean isConfirmed() {
        return driver.findElement(confirmation).getText().contains("Thank you");
    }
    public void goHomeAndLogout() {
        driver.findElement(backHomeBtn).click();
        try { Thread.sleep(1000); } catch (InterruptedException e) {}
        driver.findElement(menuBtn).click();
        try { Thread.sleep(1000); } catch (InterruptedException e) {}
        driver.findElement(logoutBtn).click();
    }
}