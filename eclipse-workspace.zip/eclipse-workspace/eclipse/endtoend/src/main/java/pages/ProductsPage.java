package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class ProductsPage {
    WebDriver driver;
    By firstProduct = By.id("add-to-cart-sauce-labs-backpack");
    By secondProduct = By.id("add-to-cart-sauce-labs-bike-light");
    By cartBadge = By.className("shopping_cart_badge");
    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }
    public void addProducts() {
        driver.findElement(firstProduct).click();
        driver.findElement(secondProduct).click();
    }
    public int getCartCount() {
        return Integer.parseInt(driver.findElement(cartBadge).getText());
    }
}
