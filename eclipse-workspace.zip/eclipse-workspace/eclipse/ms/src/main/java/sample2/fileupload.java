package sample2;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import io.github.bonigarcia.wdm.WebDriverManager;
	public class fileupload {
	    public static void main(String[] args) throws InterruptedException {
	        // Step 1: Setup ChromeDriver
	        WebDriverManager.chromedriver().setup();
	        WebDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        // Step 2: Open the file upload page
	        driver.get("https://the-internet.herokuapp.com/upload");
	        Thread.sleep(2000);
	        // Step 3: Locate the file input element
	        WebElement fileInput = driver.findElement(By.id("file-upload"));
	        // Replace with your local file path
	        String filePath = "C:\\Ashok\\aa.png";
	        fileInput.sendKeys(filePath); // Directly upload the file
	        // Step 4: Click the upload button
	        driver.findElement(By.id("file-submit")).click();
	        Thread.sleep(2000);
	        // Step 5: Verify upload success
	        String uploadedMessage = driver.findElement(By.tagName("h3")).getText();
	        System.out.println("Upload status: " + uploadedMessage);
	        // Step 6: Close the browser
	        driver.quit();
	    }
	}


