package sample2;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import io.github.bonigarcia.wdm.WebDriverManager;
	import java.util.List;
	public class tabledata {
	    public static void main(String[] args) {
	        // Step 1: Setup ChromeDriver
	        WebDriverManager.chromedriver().setup();
	        WebDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        // Step 2: Open the page with tables
	        driver.get("https://the-internet.herokuapp.com/tables");
	        // Step 3: Locate the table by ID (table1)
	        WebElement table = driver.findElement(By.id("table1"));
	        // Step 4: Get all rows (including header)
	        List<WebElement> allRows = table.findElements(By.tagName("tr"));
	        System.out.println("Total rows (including header): " + allRows.size());
	        // Step 5: Loop through rows and extract cell data
	        for (int i = 0; i < allRows.size(); i++) {
	            WebElement row = allRows.get(i);
	            List<WebElement> cells = row.findElements(By.tagName(i == 0 ? "th" : "td")); // Header or Data
	            for (WebElement cell : cells) {
	                System.out.print(cell.getText() + " | ");
	            }
	            System.out.println();
	        }
	        // Optional: Extract specific data (e.g., Email column)
	        System.out.println("\n--- Extracting Email Addresses ---");
	        List<WebElement> emailCells = table.findElements(By.xpath("//table[@id='table1']/tbody/tr/td[3]"));
	        for (WebElement email : emailCells) {
	            System.out.println(email.getText());
	        }
	        // Step 6: Close browser
	        driver.quit();
	    }
	}

