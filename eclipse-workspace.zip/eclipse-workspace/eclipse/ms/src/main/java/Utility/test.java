package Utility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;
public class test {
	public static void main(String[] args) {
	WebDriver driver = new ChromeDriver();
	driver.get("https://demoqa.com/text-box");
	WebElement username = driver.findElement(By.id("userName"));
	browser_utility.enterText(username, "John Doe");
}
}
