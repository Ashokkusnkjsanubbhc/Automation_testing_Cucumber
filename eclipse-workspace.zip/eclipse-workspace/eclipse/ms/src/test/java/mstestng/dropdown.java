package mstestng;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.Select;
	import org.testng.Assert;
	import org.testng.annotations.*;
	import io.github.bonigarcia.wdm.WebDriverManager;
	public class dropdown {
	    WebDriver driver;
	    Select dropdown;
	    @BeforeClass
	    public void setup() {
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://the-internet.herokuapp.com/dropdown");
	    }
	    @Test(priority = 1)
	    public void selectByVisibleText() {
	        dropdown = new Select(driver.findElement(By.id("dropdown")));
	        dropdown.selectByVisibleText("Option 1");
	        String selected = dropdown.getFirstSelectedOption().getText();
	        Assert.assertEquals(selected, "Option 1", "Option 1 should be selected");
	    }
	    @Test(priority = 2)
	    public void selectByValue() {
	        dropdown = new Select(driver.findElement(By.id("dropdown")));
	        dropdown.selectByValue("2");
	        String selected = dropdown.getFirstSelectedOption().getText();
	        Assert.assertEquals(selected, "Option 2", "Option 2 should be selected");
	    }
	    @Test(priority = 3)
	    public void selectByIndex() {
	        dropdown = new Select(driver.findElement(By.id("dropdown")));
	        dropdown.selectByIndex(1); // Index starts at 0
	        String selected = dropdown.getFirstSelectedOption().getText();
	        Assert.assertEquals(selected, "Option 1", "Option 1 should be selected via index");
	    }
	    @AfterClass
	    public void tearDown() {
	        driver.quit();
	    }
	
}
