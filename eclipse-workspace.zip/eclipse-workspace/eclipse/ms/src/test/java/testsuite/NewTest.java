package testsuite;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
public class NewTest {
    WebDriver driver;
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
    }
    @DataProvider(name = "loginData")
    public Object[][] loginDataProvider() {
        return new Object[][] {
            
            {"student","password123"},
            {"admin",""},
            {"", "admin123"},
            {"tomsmith","SuperSecretPassword!"},{"tomsmith","SuperSecretPassword!"}
        };
    }
    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password) {
        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        WebElement loginBtn = driver.findElement(By.id("submit"));
        usernameField.clear();
        usernameField.sendKeys(username);
        passwordField.clear();
        passwordField.sendKeys(password);
        loginBtn.click();
        // You can add validation/assertion here
        System.out.println("Tested login with: " + username + " / " + password);
    }
    @AfterClass
    public void tearDown() throws InterruptedException {
    	Thread.sleep(1000);
        driver.quit();
    }
}