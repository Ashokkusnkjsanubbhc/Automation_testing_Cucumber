package testdouble;

public class dummy implements mailservice{
 
 @Override
 public void SendEmail(String message) {
	// TODO Auto-generated method stub
	
}
}
