package testdouble;
public class reportservice {
	private mailservice emailservice;
	
	public reportservice(mailservice emailservice) {
		this.emailservice=emailservice;
		}
	public String generateReport() {
		//email is not used in this method,but needed in constructor
		return "REport generate";
	}
}



