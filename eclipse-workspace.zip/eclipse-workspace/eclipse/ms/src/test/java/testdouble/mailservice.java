package testdouble;

public interface mailservice {
 void SendEmail(String message);
}
