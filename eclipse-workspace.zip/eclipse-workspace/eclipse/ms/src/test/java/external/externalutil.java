package external;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class externalutil {
    @DataProvider(name = "excelData")
    public Object[][] excelDataProvider() throws Exception {
        String path = "C:\\Ashok\\Book1.xlsx";
        return NewTest.getExcelData(path, "Sheet1");
    }
    @Test(dataProvider = "excelData")
    public void loginTest(String username, String password) {
        System.out.println("Username: " + username + " | Password: " + password);
        // Here you can plug in Selenium WebDriver to automate login
        // For example: driver.findElement(By.id("user")).sendKeys(username);
    }

}
