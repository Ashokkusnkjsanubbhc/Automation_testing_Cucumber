package selenium;
//package selenium;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	public class login {
		public static void main(String[] args) throws InterruptedException {
			System.setProperty("Webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chrome-win64\\chrome-win64/chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://the-internet.herokuapp.com/login");
			  WebElement username = driver.findElement(By.name("username"));
		        username.clear();
		        username.sendKeys("tomsmith");
		        WebElement password = driver.findElement(By.name("password"));
		        password.clear();
		        password.sendKeys("SuperSecretPassword!");
		        // Step 3: Click the Submit button
		        WebElement submitBtn = driver.findElement(By.cssSelector("input[type='submit']"));
		        submitBtn.click();
		        driver.quit();
}
	}
