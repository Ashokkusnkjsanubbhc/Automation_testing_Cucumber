package selenium;



	//package selenium;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.Keys;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.chrome.ChromeDriver;

public class explicitywait {
			public static void main(String[] args) throws InterruptedException {
				System.setProperty("Webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chrome-win64\\chrome-win64/chromedriver.exe");
				WebDriver driver=new ChromeDriver();
				driver.get("https://the-internet.herokuapp.com/dynamic_loading/1");
				 //Open the test page
			       
			        WebElement startButton = driver.findElement(By.xpath("//div[@id='start']/button"));
			        startButton.click();
			        // Step 4: Use Explicit Wait to wait for the result text to be visible
			        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			        WebElement resultText = wait.until(
			            ExpectedConditions.visibilityOfElementLocated(By.id("finish"))
			        );
			        // Step 5: Print the result text
			        System.out.println("Text appeared: " + resultText.getText());
			        // Step 6: Close the browser
			        driver.quit();
}
}
