/**
 * 
 */
/**
 * 
 */
module Javasample_1 {
}